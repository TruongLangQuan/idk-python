# Chương 2: Hàm

11. [Viết hàm để tính giai thừa của một số.](./011.md)
12. [Viết hàm để tính tổng các số từ 1 đến n.](./012.md)
13. [Viết hàm để kiểm tra một số có phải là số nguyên tố không.](./013.md)
14. [Viết hàm để tìm số lớn nhất trong một danh sách.](./014.md)
15. [Viết hàm để tính tổng các chữ số của một số.](./015.md)
16. [Viết hàm để kiểm tra một chuỗi có phải là palindrome không.](./016.md)
17. [Viết hàm để tính lũy thừa của một số.](./017.md)
18. [Viết hàm để chuyển đổi độ C sang độ F.](./018.md)
19. [Viết hàm để tính chu vi và diện tích hình tròn.](./019.md)
20. [Viết hàm để tính chu vi và diện tích hình chữ nhật.](./020.md)
