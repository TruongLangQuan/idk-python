# Chương 6 : Set

51. [Viết chương trình để tạo một set.](./051.md)
52. [Viết chương trình để thêm một phần tử vào set.](./052.md)
53. [Viết chương trình để xóa một phần tử khỏi set.](./053.md)
54. [Viết chương trình để kiểm tra một phần tử có tồn tại trong set không.](./054.md)
55. [Viết chương trình để lấy độ dài của set.](./055.md)
56. [Viết chương trình để tìm hợp của hai set.](./056.md)
57. [Viết chương trình để tìm giao của hai set.](./057.md)
58. [Viết chương trình để tìm phần bù của hai set.](./058.md)
59. [Viết chương trình để xóa tất cả các phần tử trong set.](./059.md)
60. [Viết chương trình để chuyển đổi một danh sách thành set.](./060.md)
