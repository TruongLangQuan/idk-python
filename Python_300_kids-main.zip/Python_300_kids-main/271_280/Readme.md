# Chương 28 : Bài tập về lập trình đồ họa cơ bản

271. [Viết chương trình để vẽ hình vuông bằng Turtle.](./271.md)
272. [Viết chương trình để vẽ hình tam giác bằng Turtle.](./272.md)
273. [Viết chương trình để vẽ hình tròn bằng Turtle.](./273.md)
274. [Viết chương trình để vẽ hình ngôi sao bằng Turtle.](./274.md)
275. [Viết chương trình để vẽ hình lục giác bằng Turtle.](./275.md)
276. [Viết chương trình để vẽ hình ngũ giác bằng Turtle.](./276.md)
277. [Viết chương trình để vẽ đường tròn lồng vào nhau bằng Turtle.](./277.md)
278. [Viết chương trình để vẽ các đường thẳng song song bằng Turtle.](./278.md)
279. [Viết chương trình để vẽ các hình chữ nhật lồng vào nhau bằng Turtle.](./279.md)
280. [Viết chương trình để vẽ hoa bằng Turtle.](./280.md)
