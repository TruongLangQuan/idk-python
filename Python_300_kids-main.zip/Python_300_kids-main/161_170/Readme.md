# Chương 17 : Bài tập tổng hợp

161. [Viết chương trình để quản lý danh sách học sinh.](./161.md)
162. [Viết chương trình để quản lý thư viện sách.](./162.md)
163. [Viết chương trình để quản lý cửa hàng bán lẻ.](./163.md)
164. [Viết chương trình để quản lý kho hàng.](./164.md)
165. [Viết chương trình để quản lý nhân viên.](./165.md)
166. [Viết chương trình để quản lý lịch học.](./166.md)
167. [Viết chương trình để quản lý điểm thi.](./167.md)
168. [Viết chương trình để quản lý thông tin cá nhân.](./168.md)
169. [Viết chương trình để quản lý thu chi cá nhân.](./169.md)
170. [Viết chương trình để quản lý công việc hàng ngày.](./170.md)
