# Chương 4: Tuple

31. [Viết chương trình để tạo một tuple.](./031.md)
32. [Viết chương trình để truy cập một phần tử trong tuple.](./032.md)
33. [Viết chương trình để nối hai tuple.](./033.md)
34. [Viết chương trình để lấy độ dài của một tuple.](./034.md)
35. [Viết chương trình để chuyển đổi một tuple thành danh sách.](./035.md)
36. [Viết chương trình để chuyển đổi một danh sách thành tuple.](./036.md)
37. [Viết chương trình để kiểm tra một phần tử có tồn tại trong tuple không.](./038.md)
38. [Viết chương trình để đếm số lần xuất hiện của một phần tử trong tuple.](./038.md)
39. [Viết chương trình để tìm phần tử lớn nhất trong tuple.](./039.md)
40. [Viết chương trình để tìm phần tử nhỏ nhất trong tuple.](./040.md)
