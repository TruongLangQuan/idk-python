# Chương 26 : Bài tập với web scraping cơ bản

251. [Viết chương trình để tải xuống trang web.](./251.md)
252. [Viết chương trình để trích xuất tiêu đề của trang web.](./252.md)
253. [Viết chương trình để trích xuất tất cả các liên kết từ trang web.](./253.md)
254. [Viết chương trình để trích xuất tất cả các hình ảnh từ trang web.](./254.md)
255. [Viết chương trình để trích xuất nội dung của một bài viết từ trang web.](./255.md)
256. [Viết chương trình để trích xuất tất cả các đoạn văn từ trang web.](./256.md)
257. [Viết chương trình để trích xuất tất cả các bảng từ trang web.](257.md)
258. [Viết chương trình để trích xuất tất cả các tiêu đề từ trang web.](./258.md)
259. [Viết chương trình để trích xuất tất cả các đoạn mã nguồn từ trang web.](./259.md)
260. [Viết chương trình để trích xuất tất cả các thẻ meta từ trang web.](./260.md)
