# Chương 22 : Bài tập với SQL

211. [Viết chương trình để kết nối với cơ sở dữ liệu SQL.](./211.md)
212. [Viết chương trình để tạo bảng trong cơ sở dữ liệu SQL.](./212.md)
213. [Viết chương trình để chèn dữ liệu vào bảng trong cơ sở dữ liệu SQL.](./213.md)
214. [Viết chương trình để truy vấn dữ liệu từ bảng trong cơ sở dữ liệu SQL.](./214.md)
215. [Viết chương trình để cập nhật dữ liệu trong bảng trong cơ sở dữ liệu SQL.](./215.md)
216. [Viết chương trình để xóa dữ liệu trong bảng trong cơ sở dữ liệu SQL.](./216.md)
217. [Viết chương trình để tạo bảng quan hệ trong cơ sở dữ liệu SQL.](./217.md)
218. [Viết chương trình để thực hiện join giữa hai bảng trong cơ sở dữ liệu SQL.](./218.md)
219. [Viết chương trình để thực hiện aggregate functions trong cơ sở dữ liệu SQL.](./219.md)
220. [Viết chương trình để thực hiện subquery trong cơ sở dữ liệu SQL.](./220.md)
