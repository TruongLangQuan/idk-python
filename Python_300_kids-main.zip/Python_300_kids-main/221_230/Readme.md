# Chương 23 : Xử lý dữ liệu cơ bản

221. [Viết chương trình để đọc dữ liệu từ tệp CSV.](./221.md)
222. [Viết chương trình để ghi dữ liệu vào tệp CSV.](./222.md)
223. [Viết chương trình để đọc dữ liệu từ tệp Excel.](./223.md)
224. [Viết chương trình để ghi dữ liệu vào tệp Excel.](./224.md)
225. [Viết chương trình để đọc dữ liệu từ tệp JSON.](./225.md)
226. [Viết chương trình để ghi dữ liệu vào tệp JSON.](./226.md)
227. [Viết chương trình để phân tích dữ liệu từ tệp CSV.](./227.md)
228. [Viết chương trình để phân tích dữ liệu từ tệp Excel.](./228.md)
229. [Viết chương trình để phân tích dữ liệu từ tệp JSON.](./229.md)
230. [Viết chương trình để tạo báo cáo dữ liệu đơn giản.](./230.md)