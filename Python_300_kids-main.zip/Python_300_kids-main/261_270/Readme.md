# Chương 27 : Bài toán ma trận cơ bản

261. [Viết chương trình để tính tổng của hai ma trận.](./261.md)
262. [Viết chương trình để tính hiệu của hai ma trận.](./262.md)
263. [Viết chương trình để tính tích của hai ma trận.](./263.md)
264. [Viết chương trình để tính định thức của một ma trận.](./264.md)
265. [Viết chương trình để tính ma trận nghịch đảo của một ma trận.](./265.md)
266. [Viết chương trình để tính ma trận chuyển vị của một ma trận.](./266.md)
267. [Viết chương trình để tính hạng của một ma trận.](./267.md)
268. [Viết chương trình để kiểm tra một ma trận có phải là ma trận đơn vị không.](./268.md)
269. [Viết chương trình để kiểm tra một ma trận có phải là ma trận đối xứng không.](./269.md)
270. [Viết chương trình để kiểm tra một ma trận có phải là ma trận tam giác trên không.](./270.md)
