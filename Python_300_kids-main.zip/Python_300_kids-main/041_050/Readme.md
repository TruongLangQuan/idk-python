# Chương 5 : Dictionary

41. [Viết chương trình để tạo một dictionary.](./041.md)
42. [Viết chương trình để truy cập giá trị của một key trong dictionary.](./042.md)
43. [Viết chương trình để thêm một cặp key-value vào dictionary.](./043.md)
44. [Viết chương trình để xóa một cặp key-value khỏi dictionary.](./044.md)
45. [Viết chương trình để kiểm tra một key có tồn tại trong dictionary không.](./045.md)
46. [Viết chương trình để lấy tất cả các key trong dictionary.](./046.md)
47. [Viết chương trình để lấy tất cả các giá trị trong dictionary.](./047.md)
48. [Viết chương trình để lấy tất cả các cặp key-value trong dictionary.](./048.md)
49. [Viết chương trình để đếm số lượng cặp key-value trong dictionary.](./049.md)
50. [Viết chương trình để nối hai dictionary.](./050.md)
