# Chương 11 : Xử lý văn bản

101. [Viết chương trình để đếm số từ trong một chuỗi.](./101.md)
102. [Viết chương trình để đếm số ký tự trong một chuỗi.](./102.md)
103. [Viết chương trình để đếm số câu trong một đoạn văn.](./103.md)
104. [Viết chương trình để tìm tất cả các từ dài nhất trong một chuỗi.](./104.md)
105. [Viết chương trình để tìm từ xuất hiện nhiều nhất trong một chuỗi.](./105.md)
106. [Viết chương trình để tách các từ từ một chuỗi thành danh sách.](./106.md)
107. [Viết chương trình để nối các từ trong danh sách thành một chuỗi.](./107.md)
108. [Viết chương trình để thay thế một từ trong chuỗi bằng từ khác.](./108.md)
109. [Viết chương trình để loại bỏ các ký tự đặc biệt khỏi chuỗi.](./109.md)
110. [Viết chương trình để kiểm tra một chuỗi có phải là palindrome không.](./110.md)
