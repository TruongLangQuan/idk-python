# Chương 16 : Giao diện (GUI) cơ bản

151. [Viết chương trình để tạo một cửa sổ GUI đơn giản.](./151.md)
152. [Viết chương trình để thêm nút vào cửa sổ GUI.](./152.md)
153. [Viết chương trình để thêm hộp văn bản vào cửa sổ GUI.](./153.md)
154. [Viết chương trình để thêm nhãn vào cửa sổ GUI.](./154.md)
155. [Viết chương trình để thêm menu vào cửa sổ GUI.](./155.md)
156. [Viết chương trình để thêm hộp thoại thông báo vào cửa sổ GUI.](./156.md)
157. [Viết chương trình để thêm hình ảnh vào cửa sổ GUI.](./157.md)
158. [Viết chương trình để thêm bảng vào cửa sổ GUI.](./158.md)
159. [Viết chương trình để thêm đồ thị vào cửa sổ GUI.](./159.md)
160. [Viết chương trình để tạo ứng dụng máy tính đơn giản với GUI.](./160.md)
