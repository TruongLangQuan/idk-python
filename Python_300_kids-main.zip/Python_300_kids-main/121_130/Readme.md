# Chương 13 : Lập trình hàm

121. [Viết chương trình để sử dụng hàm map để nhân đôi các phần tử trong danh sách.](./121.md)
122. [Viết chương trình để sử dụng hàm filter để lọc các số chẵn trong danh sách.](./122.md)
123. [Viết chương trình để sử dụng hàm reduce để tính tổng các phần tử trong danh sách.](./123.md)
124. [Viết chương trình để sử dụng hàm lambda để tính lũy thừa của một số.](./124.md)
125. [Viết chương trình để sử dụng hàm lambda để kiểm tra số chẵn lẻ.](./125.md)
126. [Viết chương trình để sử dụng hàm map với lambda để nhân đôi các phần tử trong danh sách.](./126.md)
127. [Viết chương trình để sử dụng hàm filter với lambda để lọc các số lớn hơn 10 trong danh sách.](./127.md)
128. [Viết chương trình để sử dụng hàm reduce với lambda để tính tích các phần tử trong danh sách.](./128.md)
129. [Viết chương trình để sử dụng hàm lambda để sắp xếp danh sách từ điển theo giá trị.](./129.md)
130. [Viết chương trình để sử dụng hàm lambda để tìm số lớn nhất trong danh sách.](./130.md)
