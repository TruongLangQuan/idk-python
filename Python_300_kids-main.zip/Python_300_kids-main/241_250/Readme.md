# Chương 25 : Bài tập với API cơ bản

241. [Viết chương trình để gửi yêu cầu GET đến API và lấy dữ liệu.](./241.md)
242. [Viết chương trình để gửi yêu cầu POST đến API và lấy dữ liệu.](./242.md)
243. [Viết chương trình để phân tích dữ liệu JSON từ API.](./243.md)
244. [Viết chương trình để gửi yêu cầu PUT đến API và cập nhật dữ liệu.](./244.md)
245. [Viết chương trình để gửi yêu cầu DELETE đến API và xóa dữ liệu.](./245.md)
246. [Viết chương trình để xử lý lỗi khi gọi API.](./246.md)
247. [Viết chương trình để kiểm tra trạng thái của API.](./247.md)
248. [Viết chương trình để xác thực người dùng khi gọi API.](./248.md)
249. [Viết chương trình để lấy dữ liệu thời tiết từ API.](./249.md)
250. [Viết chương trình để lấy dữ liệu tỷ giá hối đoái từ API.](./250.md)