# Chương 14 : Bài toán thuật toán

131. [Viết chương trình để tính dãy Fibonacci.](./131.md)
132. [Viết chương trình để in ra 10 số hạnh phúc đầu tiên.](./132.md)
133. [Viết chương trình để tìm bội số chung nhỏ nhất (BSCNN) của hai số.](./133.md)
134. [Viết chương trình để kiểm tra một số có phải là số nguyên tố không.](./134.md)
135. [Viết chương trình để tìm tất cả các số nguyên tố từ 1 đến 100.](./135.md)
136. [Viết chương trình để tính tổng các số từ 1 đến n.](./136.md)
137. [Viết chương trình để tính sin(x) & cos(x) bằng các triển khai chuỗi Taylor.](./137.md)
138. [Viết chương trình để tính Lôgarit tự nhiên ln(x).](./138.md)
139. [Viết chương trình để in ra n số hoàn hảo đầu tiên.](./139.md)
140. [Viết chương trình để in ra các số Armstrong từ 1 đến 1000.](./140.md)
