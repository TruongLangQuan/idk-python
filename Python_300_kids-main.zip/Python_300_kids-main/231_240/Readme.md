# Chương 24 : Thực hành lập trình mạng cơ bản

231. [Viết chương trình để tải xuống một tệp từ internet.](./231.md)
232. [Viết chương trình để kiểm tra kết nối internet.](./232.md)
233. [Viết chương trình để kiểm tra tốc độ internet.](./233.md)
234. [Viết chương trình để gửi email.](./234.md)
235. [Viết chương trình để nhận email.](./235.md)
236. [Viết chương trình để phân giải tên miền.](./236.md)
237. [Viết chương trình để tạo một máy chủ TCP đơn giản.](./237.md)
238. [Viết chương trình để tạo một máy khách TCP đơn giản.](./238.md)
239. [Viết chương trình để tạo một máy chủ UDP đơn giản.](./239.md)
240. [Viết chương trình để tạo một máy khách UDP đơn giản.](./240.md)
