# Chương 15 : Bài toán số học

141. [Viết chương trình để tính tổng, hiệu, tích và thương của hai phân số.](./141.md)
142. [Viết chương trình để tìm nghiệm của phương trình bậc 2 (ax^2 + bx + c = 0).](./142.md)
143. [Viết chương trình để tìm nghiệm của hệ phương trình bậc nhất 2 ẩn số x & y.](./143.md)
144. [Viết chương trình để tìm các bộ ba Pythagorean nhỏ hơn 100 là 3 số nguyên liên tiếp hoặc 3 số chẵn liên tiếp.](./144.md)
145. [Viết chương trình để tính lũy thừa của một số.](./145.md)
146. [Viết chương trình để tính Tính căn bậc hai của một số nguyên dương x bằng thuật toán Babylonian.](./146.md)
147. [Viết chương trình để kiểm tra một số có phải là số hoàn hảo không.](./147.md)
148. [Viết chương trình liệt kê, đếm và tính tổng các ước số của số nguyên dương n.](./148.md)
149. [Viết chương trình để nhập vào một số nguyên dương n, phân tích n thành các thừa số nguyên tố.](./149.md)
150. [Viết chương trình để tìm khoảng cách của 2 điểm A & B trong hệ tọa độ Oxy.](./150.md)
