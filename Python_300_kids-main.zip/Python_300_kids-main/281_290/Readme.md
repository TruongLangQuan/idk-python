# Chương 29 : Khoa học dữ liệu cơ bản

281. [Viết chương trình để tính trung bình, median và mode của một danh sách số.](./281.md)
282. [Viết chương trình để tính phương sai và độ lệch chuẩn của một danh sách số.](./282.md)
283. [Viết chương trình để vẽ biểu đồ phân phối của một danh sách số.](./283.md)
284. [Viết chương trình để vẽ biểu đồ boxplot của một danh sách số.](./284.md)
285. [Viết chương trình để vẽ biểu đồ scatterplot của hai danh sách số.](./285.md)
286. [Viết chương trình để tính ma trận tương quan của hai danh sách số.](./286.md)
287. [Viết chương trình để thực hiện phân tích hồi quy đơn giản.](./287.md)
288. [Viết chương trình để thực hiện phân tích hồi quy đa biến.](./288.md)
289. [Viết chương trình để phân tích dữ liệu sử dụng Pandas.](./289.md)
290. [Viết chương trình để phân tích dữ liệu sử dụng Numpy.](./290.md)
