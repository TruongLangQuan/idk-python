# Chương 1: Cấu trúc điều khiển

1. [Viết chương trình để kiểm tra số nguyên dương hay âm.](./001.md)
2. [Viết chương trình để kiểm tra số chẵn hay lẻ.](./002.md)
3. [Viết chương trình để tìm số lớn nhất trong ba số.](./003.md)
4. [Viết chương trình để tính tiền taxi dựa trên số km đã đi.](./004.md)
5. [Viết chương trình để tính điểm trung bình và xếp loại học sinh.](./005.md)
6. [Viết chương trình để in bảng cửu chương.](./006.md)
7. [Viết chương trình để kiểm tra một năm có phải năm nhuận không.](./007.md)
8. [Viết chương trình để đếm số lượng số chẵn và lẻ trong một danh sách.](./008.md)
9. [Viết chương trình để in tất cả các số nguyên tố từ 1 đến 100.](./009.md)
10. [Viết chương trình để tìm ước số chung lớn nhất (USCLN) của hai số.](./010.md)
