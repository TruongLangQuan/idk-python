# Chương 20 : Generator

191. [Viết chương trình để tạo một generator sinh ra các số nguyên từ 1 đến n.](./191.md)
192. [Viết chương trình để tạo một generator sinh ra các số Fibonacci.](./192.md)
193. [Viết chương trình để tạo một generator sinh ra các số nguyên tố.](./193.md)
194. [Viết chương trình để tạo một generator sinh ra các số chẵn.](./194.md)
195. [Viết chương trình để tạo một generator sinh ra các số lẻ.](./195.md)
196. [Viết chương trình để tạo một generator sinh ra các chuỗi từ một danh sách các từ.](./196.md)
197. [Viết chương trình để tạo một generator sinh ra các chuỗi hoàn hảo.](./197.md)
198. [Viết chương trình để tạo một generator sinh ra các số Armstrong.](./198.md)
199. [Viết chương trình để tạo một generator sinh ra các số hoàn hảo.](./199.md)
200. [Viết chương trình để tạo một generator sinh ra các số chính phương.](./200.md)
