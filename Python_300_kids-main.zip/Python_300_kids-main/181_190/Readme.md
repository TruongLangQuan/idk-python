# Chương 19 : Iterator

181. [Viết chương trình để tạo một iterator từ một list.](./181.md)
182. [Viết chương trình để tạo một iterator từ một tuple.](./182.md)
183. [Viết chương trình để tạo một iterator từ một chuỗi.](./183.md)
184. [Viết chương trình để lặp qua một iterator.](./184.md)
185. [Viết chương trình để sử dụng hàm next() để truy cập các phần tử của một iterator.](./185.md)
186. [Viết chương trình để tạo một iterator tùy chỉnh.](./186.md)
187. [Viết chương trình để sử dụng itertools để tạo ra một permutation.](./187.md)
188. [Viết chương trình để sử dụng itertools để tạo ra một combination.](./188.md)
189. [Viết chương trình để sử dụng itertools để tạo ra một product.](./189.md)
190. [Viết chương trình để sử dụng itertools để tạo ra một combinations_with_replacement.](./190.md)
