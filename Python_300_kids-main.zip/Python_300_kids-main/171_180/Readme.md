# Chương 18 : Decorator

171. [Viết chương trình để tạo một decorator đơn giản.](./171.md)
172. [Viết chương trình để tạo một decorator chấp nhận đối số.](172.md)
173. [Viết chương trình để tạo một decorator với nhiều hàm trả về.](./173.md)
174. [Viết chương trình để tạo một decorator gọi một hàm nhiều lần.](./174.md)
175. [Viết chương trình để tạo một decorator sửa đổi giá trị trả về của một hàm.](./175.md)
176. [Viết chương trình để tạo một decorator kiểm tra thời gian thực thi của một hàm.](./176.md)
177. [Viết chương trình để tạo một decorator giới hạn số lần gọi một hàm.](./177.md)
178. [Viết chương trình để tạo một decorator chuyển đổi giá trị trả về thành một kiểu dữ liệu khác.](./178.md)
179. [Viết chương trình để tạo một decorator nhận một đối số từ bên ngoài.](./179.md)
180. [Viết chương trình để tạo một decorator sử dụng hàm generator.](./180.md)
