# Chương 21 : Vẽ đồ thị

201. [Viết chương trình để vẽ đồ thị đường bằng Matplotlib.](./201.md)
202. [Viết chương trình để vẽ đồ thị cột bằng Matplotlib.](./202.md)
203. [Viết chương trình để vẽ đồ thị tròn bằng Matplotlib.](203.md)
204. [Viết chương trình để vẽ đồ thị tán xạ bằng Matplotlib.](204.md)
205. [Viết chương trình để vẽ đồ thị hộp bằng Matplotlib.](./205.md)
206. [Viết chương trình để vẽ đồ thị thanh ngang bằng Matplotlib.](./206.md)
207. [Viết chương trình để vẽ đồ thị đường cong bằng Matplotlib.](./207.md)
208. [Viết chương trình để vẽ đồ thị 3D bằng Matplotlib.](./208.md)
209. [Viết chương trình để vẽ đồ thị heatmap bằng Seaborn.](./209.md)
210. [Viết chương trình để vẽ đồ thị histogram bằng Seaborn.](./210.md)
