# Chương 8 : File I/O

71. [Viết chương trình để đọc nội dung của một file văn bản.](./071.md)
72. [Viết chương trình để ghi nội dung vào một file văn bản.](./072.md)
73. [Viết chương trình để đếm số dòng trong một file văn bản.](./073.md)
74. [Viết chương trình để đếm số từ trong một file văn bản.](./074.md)
75. [Viết chương trình để đếm số ký tự trong một file văn bản.](./075.md)
76. [Viết chương trình để kiểm tra một file có tồn tại không.](./076.md)
77. [Viết chương trình để xóa một file văn bản.](./077.md)
78. [Viết chương trình để đọc file theo từng dòng.](./078.md)
79. [Viết chương trình để ghi thêm nội dung vào cuối file.](./079.md)
80. [Viết chương trình để sao chép nội dung của một file sang file khác.](./080.md)
