# Chương 30 : Xử lý ảnh

291. [Viết chương trình để đọc một ảnh từ file.](./291.md)
292. [Viết chương trình để hiển thị một ảnh.](./292.md)
293. [Viết chương trình để lưu một ảnh vào file.](./293.md)
294. [Viết chương trình để chuyển đổi ảnh màu thành ảnh xám.](./294.md)
295. [Viết chương trình để làm mờ ảnh.](./295.md)
296. [Viết chương trình để phát hiện cạnh trong ảnh.](./296.md)
297. [Viết chương trình để lọc ảnh.](./297.md)
298. [Viết chương trình để thay đổi kích thước ảnh.](./298.md)
299. [Viết chương trình để cắt ảnh.](./299.md)
290. [Viết chương trình để xoay ảnh.](./300.md)