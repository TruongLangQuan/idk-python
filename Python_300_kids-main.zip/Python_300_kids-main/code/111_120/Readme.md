# Chương 12 : Xử lý ngày và thời gian

111. [Viết chương trình để lấy ngày và giờ hiện tại.](./111.py)
112. [Viết chương trình để lấy ngày hiện tại.](112.py)
113. [Viết chương trình để lấy thời gian hiện tại.](./113.py)
114. [Viết chương trình để chuyển đổi định dạng ngày tháng.](./114.py)
115. [Viết chương trình để tính thời gian chênh lệch giữa hai ngày.](./115.py)
116. [Viết chương trình để tính thời gian chênh lệch giữa hai thời gian.](./116.py)
117. [Viết chương trình để tính số ngày từ ngày hiện tại đến một ngày nhất định.](./117.py)
118. [Viết chương trình để tính số giây từ thời gian hiện tại đến một thời gian nhất định.](./118.py)
119. [Viết chương trình để in lịch của một tháng nhất định.](./119.py)
120. [Viết chương trình để in lịch của một năm nhất định.](./120.py)
