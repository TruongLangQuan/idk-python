# 064 - Viết chương trình để chuyển đổi chuỗi thành chữ hoa

input_str = "hello world"
print("Chuỗi ban đầu:", input_str)

# Chuyển đổi chuỗi thành chữ hoa
upper_str = input_str.upper()
print("Chuỗi sau khi chuyển đổi thành chữ hoa:", upper_str)