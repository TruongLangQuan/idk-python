# 061 - Viết chương trình để tạo một chuỗi

# Tạo một chuỗi
str1 = "Hello, World!"
print(str1)

str1 = "Hello, World!"
str2 = 'Hello, World!'

str3 = """Hello,
World!"""
str4 = '''Hello,
World!'''

num = 123
str5 = str(num)  # '123'

str6 = "Hello, " + "World!"

name = "World"
str7 = f"Hello, {name}!"

name = "World"
str8 = "Hello, {}!".format(name)