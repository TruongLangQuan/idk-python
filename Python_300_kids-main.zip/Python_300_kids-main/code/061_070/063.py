# 063 - Viết chương trình để lấy độ dài của chuỗi

# Tạo một chuỗi
str1 = "Hello, World!"

# Lấy độ dài của chuỗi
length = len(str1)
print(length)

# Hoặc sử dụng vòng lặp
# Tạo một chuỗi
str1 = "Hello, World!"

# Lấy độ dài của chuỗi
length = 0
for char in str1:
    length += 1
print(length)