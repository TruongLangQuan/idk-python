# 060 - Viết chương trình để chuyển đổi một danh sách thành set

# Khởi tạo danh sách
list1 = [1, 2, 3, 4, 5]
print("Danh sách ban đầu:", list1)

# Chuyển đổi danh sách thành set
set1 = set(list1)
print("Set sau khi chuyển đổi từ danh sách:", set1)