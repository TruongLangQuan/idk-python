# Chương 6 : Set

51. [Viết chương trình để tạo một set.](./051.py)
52. [Viết chương trình để thêm một phần tử vào set.](./052.py)
53. [Viết chương trình để xóa một phần tử khỏi set.](./053.py)
54. [Viết chương trình để kiểm tra một phần tử có tồn tại trong set không.](./054.py)
55. [Viết chương trình để lấy độ dài của set.](./055.py)
56. [Viết chương trình để tìm hợp của hai set.](./056.py)
57. [Viết chương trình để tìm giao của hai set.](./057.py)
58. [Viết chương trình để tìm phần bù của hai set.](./058.py)
59. [Viết chương trình để xóa tất cả các phần tử trong set.](./059.py)
60. [Viết chương trình để chuyển đổi một danh sách thành set.](./060.py)
