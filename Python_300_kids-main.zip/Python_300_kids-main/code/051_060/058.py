# 058 - Viết chương trình để tìm phần bù của hai set

# Khởi tạo hai set ban đầu
set1 = {'apple', 'banana', 'cherry'}
set2 = {'banana', 'cherry', 'durian'}
print("Set 1:", set1)
print("Set 2:", set2)

# Tìm phần bù của hai set
set_difference = set1 - set2
print("Phần bù của hai set:", set_difference)