# 055 - Viết chương trình để lấy độ dài của set

# Khởi tạo một set ban đầu
my_set = {'apple', 'banana', 'cherry'}
print("Set ban đầu:", my_set)

# Lấy độ dài của set
length = len(my_set)
print("Độ dài của set:", length)