# 051 - Viết chương trình để tạo một set

# Phương pháp 1: Sử dụng dấu ngoặc nhọn {} để tạo một set
set1 = {'apple', 'banana', 'cherry'}
print("Set tạo bằng dấu ngoặc nhọn {}:", set1)

# Phương pháp 2: Sử dụng hàm set() để tạo một set
set2 = set(['apple', 'banana', 'cherry'])
print("Set tạo bằng hàm set():", set2)
