# 059 - Viết chương trình để xóa tất cả các phần tử trong set

# Khởi tạo set
set1 = {1, 2, 3, 4, 5}
print("Set ban đầu:", set1)

# Xóa tất cả các phần tử trong set
set1.clear()
print("Set sau khi xóa tất cả các phần tử:", set1)