# 057 - Viết chương trình để tìm giao của hai set

# Khởi tạo hai set ban đầu
set1 = {'apple', 'banana', 'cherry'}
set2 = {'banana', 'cherry', 'durian'}
print("Set 1:", set1)
print("Set 2:", set2)

# Tìm giao của hai set
set_intersection = set1 & set2
print("Giao của hai set:", set_intersection)