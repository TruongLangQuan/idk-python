# 056 - Viết chương trình để tìm hợp của hai set

# Khởi tạo hai set ban đầu
set1 = {'apple', 'banana', 'cherry'}
set2 = {'banana', 'cherry', 'durian'}
print("Set 1:", set1)
print("Set 2:", set2)

# Tìm hợp của hai set
set_union = set1 | set2
print("Hợp của hai set:", set_union)