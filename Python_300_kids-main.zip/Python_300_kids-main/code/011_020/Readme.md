# Chương 2: Hàm

11. [Viết hàm để tính giai thừa của một số.](./011_1.py) | [(2)](./011_2.py)
12. [Viết hàm để tính tổng các số từ 1 đến n.](./012.py)
13. [Viết hàm để kiểm tra một số có phải là số nguyên tố không.](./013.py)
14. [Viết hàm để tìm số lớn nhất trong một danh sách.](./014.py)
15. [Viết hàm để tính tổng các chữ số của một số.](./015.py)
16. [Viết hàm để kiểm tra một chuỗi có phải là palindrome không.](./016.py)
17. [Viết hàm để tính lũy thừa của một số.](./017.py)
18. [Viết hàm để chuyển đổi độ C sang độ F.](./018.py)
19. [Viết hàm để tính chu vi và diện tích hình tròn.](./019.py)
20. [Viết hàm để tính chu vi và diện tích hình chữ nhật.](./020.py)
