# 145 - Viết chương trình để tính lũy thừa của một số

def power(base, exponent):
    return base ** exponent

# Test
print(power(2, 3))

def power2(base, exponent):
    return pow(base, exponent)

# Test
print(power2(2, 3))