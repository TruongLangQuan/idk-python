# Chương 14 : Bài toán thuật toán

131. [Viết chương trình để tính dãy Fibonacci.](./131.py)
132. [Viết chương trình để in ra 10 số hạnh phúc đầu tiên.](./132.py)
133. [Viết chương trình để tìm bội số chung nhỏ nhất (BSCNN) của hai số.](./133.py)
134. [Viết chương trình để kiểm tra một số có phải là số nguyên tố không.](./134.py)
135. [Viết chương trình để tìm tất cả các số nguyên tố từ 1 đến 100.](./135.py)
136. [Viết chương trình để tính tổng các số từ 1 đến n.](./136.py)
137. [Viết chương trình để tính sin(x) & cos(x) bằng các triển khai chuỗi Taylor.](./137.py)
138. [Viết chương trình để tính Lôgarit tự nhiên ln(x).](./138.py)
139. [Viết chương trình để in ra n số hoàn hảo đầu tiên.](./139.py)
140. [Viết chương trình để in ra các số Armstrong từ 1 đến 1000.](./140.py)
