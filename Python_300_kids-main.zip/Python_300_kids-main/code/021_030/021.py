# 021 - Viết chương trình để tạo danh sách các số từ 1 đến 100

# Tạo danh sách các số từ 1 đến 100
numbers = list(range(1, 101))

# In danh sách ra màn hình
print(numbers)
