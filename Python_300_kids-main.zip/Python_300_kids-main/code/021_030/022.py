# 022 - Viết chương trình để thêm một phần tử vào cuối danh sách

# Khởi tạo danh sách ban đầu
my_list = [1, 2, 3, 4, 5]

# Nhập phần tử muốn thêm từ người dùng
new_element = input("Nhập phần tử muốn thêm vào danh sách: ")

# Thêm phần tử vào cuối danh sách
my_list.append(new_element)

# In danh sách sau khi thêm phần tử
print("Danh sách sau khi thêm phần tử:", my_list)
