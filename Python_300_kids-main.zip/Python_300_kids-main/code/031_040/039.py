# 039 - Viết chương trình để tìm phần tử lớn nhất trong tuple

# Khởi tạo một tuple
my_tuple = (10, 20, 30, 40, 50)
print("Tuple đã tạo:", my_tuple)

# Tìm phần tử lớn nhất trong tuple
max_element = max(my_tuple)

# In ra phần tử lớn nhất
print("Phần tử lớn nhất trong tuple là:", max_element)
