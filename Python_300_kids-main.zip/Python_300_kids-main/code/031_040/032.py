# 032 - Viết chương trình để truy cập một phần tử trong tuple

# Khởi tạo một tuple
my_tuple = (10, 20, 30, 40, 50)

# Truy cập phần tử ở vị trí thứ 2 (chỉ số bắt đầu từ 0)
element = my_tuple[2]

# In ra phần tử đã truy cập
print("Phần tử ở vị trí thứ 2 trong tuple là:", element)