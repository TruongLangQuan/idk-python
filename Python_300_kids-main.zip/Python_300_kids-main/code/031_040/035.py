# 035 - Viết chương trình để chuyển đổi một tuple thành danh sách

# Khởi tạo một tuple
my_tuple = (10, 20, 30, 40, 50)
print("Tuple đã tạo:", my_tuple)

# Chuyển đổi tuple thành danh sách
my_list = list(my_tuple)

# In ra danh sách đã chuyển đổi
print("Danh sách sau khi chuyển đổi từ tuple:", my_list)
