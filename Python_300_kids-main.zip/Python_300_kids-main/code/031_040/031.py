# 031 - Viết chương trình để tạo một tuple

# Khởi tạo một tuple
my_tuple = (1, 2, 3, 4, 5)

# In tuple đã tạo
print("Tuple đã tạo:", my_tuple)

# Khởi tạo một tuple
my_tuple2 = (1, "a", 3.14, True, 5)

# In tuple đã tạo
print("Tuple đã tạo:", my_tuple2)