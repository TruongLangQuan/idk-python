# 033 - Viết chương trình để nối hai tuple

# Khởi tạo hai tuple
tuple1 = (1, 2, 3)
tuple2 = ("a", "b", "c")

# Nối hai tuple lại với nhau
combined_tuple = tuple1 + tuple2

# In ra tuple kết quả
print("Tuple sau khi nối:", combined_tuple)