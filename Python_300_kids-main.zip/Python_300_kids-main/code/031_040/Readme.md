# Chương 4: Tuple

31. [Viết chương trình để tạo một tuple.](./031.py)
32. [Viết chương trình để truy cập một phần tử trong tuple.](./032.py)
33. [Viết chương trình để nối hai tuple.](./033.py)
34. [Viết chương trình để lấy độ dài của một tuple.](./034.py)
35. [Viết chương trình để chuyển đổi một tuple thành danh sách.](./035.py)
36. [Viết chương trình để chuyển đổi một danh sách thành tuple.](./036.py)
37. [Viết chương trình để kiểm tra một phần tử có tồn tại trong tuple không.](./038.py)
38. [Viết chương trình để đếm số lần xuất hiện của một phần tử trong tuple.](./038.py)
39. [Viết chương trình để tìm phần tử lớn nhất trong tuple.](./039.py)
40. [Viết chương trình để tìm phần tử nhỏ nhất trong tuple.](./040.py)
