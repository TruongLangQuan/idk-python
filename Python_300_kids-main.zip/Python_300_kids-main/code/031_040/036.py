# 036 - Viết chương trình để chuyển đổi một danh sách thành tuple

# Khởi tạo một danh sách
my_list = [10, 20, 30, 40, 50]
print("Danh sách đã tạo:", my_list)

# Chuyển đổi danh sách thành tuple
my_tuple = tuple(my_list)

# In ra tuple đã chuyển đổi
print("Tuple sau khi chuyển đổi từ danh sách:", my_tuple)
