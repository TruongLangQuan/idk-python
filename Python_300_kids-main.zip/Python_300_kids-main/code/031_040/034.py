# 034 - Viết chương trình để lấy độ dài của một tuple

# Khởi tạo một tuple
my_tuple = (10, 20, 30, 40, 50)

# Lấy độ dài của tuple
tuple_length = len(my_tuple)

# In ra độ dài của tuple
print("Độ dài của tuple là:", tuple_length)
