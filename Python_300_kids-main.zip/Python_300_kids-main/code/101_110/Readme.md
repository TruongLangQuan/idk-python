# Chương 11 : Xử lý văn bản

101. [Viết chương trình để đếm số từ trong một chuỗi.](./101.py)
102. [Viết chương trình để đếm số ký tự trong một chuỗi.](./102.py)
103. [Viết chương trình để đếm số câu trong một đoạn văn.](./103.py)
104. [Viết chương trình để tìm tất cả các từ dài nhất trong một chuỗi.](./104.py)
105. [Viết chương trình để tìm từ xuất hiện nhiều nhất trong một chuỗi.](./105.py)
106. [Viết chương trình để tách các từ từ một chuỗi thành danh sách.](./106.py)
107. [Viết chương trình để nối các từ trong danh sách thành một chuỗi.](./107.py)
108. [Viết chương trình để thay thế một từ trong chuỗi bằng từ khác.](./108.py)
109. [Viết chương trình để loại bỏ các ký tự đặc biệt khỏi chuỗi.](./109.py)
110. [Viết chương trình để kiểm tra một chuỗi có phải là palindrome không.](./110.py)
