# 002 - Viết chương trình để kiểm tra số chẵn hay lẻ.

num = int(input("Nhập một số: "))

if num % 2 == 0:
    print("Số chẵn")
else:
    print("Số lẻ")