# Chương 1: Cấu trúc điều khiển

1. [Viết chương trình để kiểm tra số nguyên dương hay âm.](./001_1.py) | [(2)](./001_2.py)
2. [Viết chương trình để kiểm tra số chẵn hay lẻ.](./002_1.py) | [(2)](./002_2.py)
3. [Viết chương trình để tìm số lớn nhất trong ba số.](./003.py)
4. [Viết chương trình để tính tiền taxi dựa trên số km đã đi.](./004.py)
5. [Viết chương trình để tính điểm trung bình và xếp loại học sinh.](./005.py)
6. [Viết chương trình để in bảng cửu chương.](./006.py)
7. [Viết chương trình để kiểm tra một năm có phải năm nhuận không.](./007.py)
8. [Viết chương trình để đếm số lượng số chẵn và lẻ trong một danh sách.](./008.py)
9. [Viết chương trình để in tất cả các số nguyên tố từ 1 đến 100.](./009.py)
10. [Viết chương trình để tìm ước số chung lớn nhất (USCLN) của hai số.](./010.py)
