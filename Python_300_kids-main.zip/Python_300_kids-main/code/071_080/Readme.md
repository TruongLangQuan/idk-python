# Chương 8 : File I/O

71. [Viết chương trình để đọc nội dung của một file văn bản.](./071.py)
72. [Viết chương trình để ghi nội dung vào một file văn bản.](./072.py)
73. [Viết chương trình để đếm số dòng trong một file văn bản.](./073.py)
74. [Viết chương trình để đếm số từ trong một file văn bản.](./074.py)
75. [Viết chương trình để đếm số ký tự trong một file văn bản.](./075.py)
76. [Viết chương trình để kiểm tra một file có tồn tại không.](./076.py)
77. [Viết chương trình để xóa một file văn bản.](./077.py)
78. [Viết chương trình để đọc file theo từng dòng.](./078.py)
79. [Viết chương trình để ghi thêm nội dung vào cuối file.](./079.py)
80. [Viết chương trình để sao chép nội dung của một file sang file khác.](./080.py)
