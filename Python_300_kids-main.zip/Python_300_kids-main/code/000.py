# Chào thế giới

print ('Chào thế giới!')